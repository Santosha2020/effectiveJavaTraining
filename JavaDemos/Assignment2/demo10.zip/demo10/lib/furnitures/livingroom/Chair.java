package furnitures.livingroom;

public class Chair{
    public int price(){return 1000;}
}