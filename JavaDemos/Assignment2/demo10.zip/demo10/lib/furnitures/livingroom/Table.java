package furnitures.livingroom;

public class Table{
   public int price(){return 5000;} 
}