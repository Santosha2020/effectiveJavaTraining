package furnitures.office;

public class Chair{
    public int price(){return 1000;}
}