package furnitures.office;

public class Table{
   public int price(){return 5000;} 
}