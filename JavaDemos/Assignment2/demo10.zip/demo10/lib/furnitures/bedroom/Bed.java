package furnitures.bedroom;  //Bed is part of furniture package and bedroom sub package

public class Bed{
   public int price(){return 10000;} 
}