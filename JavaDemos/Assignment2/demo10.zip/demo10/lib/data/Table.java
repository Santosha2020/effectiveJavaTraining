package data;

public class Table{
    void add(){
        System.out.println("item added to the list");
    }
}