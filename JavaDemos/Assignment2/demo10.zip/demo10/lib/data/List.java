package data;  //we decided that my package starts with data.

public class List{
    void add(){
        System.out.println("item added to the list");
    }
}